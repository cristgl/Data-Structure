var searchData=
[
  ['primarytype',['PrimaryType',['../classcrimen.html#acc4a8a9f688d306a38519899a8c325a7',1,'crimen']]]
];
