var searchData=
[
  ['latitude',['Latitude',['../classcrimen.html#adaf728df1dacff5a93678d3feb512b7f',1,'crimen']]],
  ['load',['load',['../principal_8cpp.html#ace66e6613caeee9e4eff28e999a58da1',1,'principal.cpp']]],
  ['locationdescription',['LocationDescription',['../classcrimen.html#a221f7065c470883388174f19ea34d1f3',1,'crimen']]],
  ['longitude',['Longitude',['../classcrimen.html#a9ffd3c64d12cc4b963b890b8db645964',1,'crimen']]]
];
