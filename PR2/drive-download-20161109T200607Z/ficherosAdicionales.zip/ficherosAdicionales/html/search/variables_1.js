var searchData=
[
  ['casenumber',['CaseNumber',['../classcrimen.html#a710fbf07b3e543c2a1b2e625b144050a',1,'crimen']]]
];
