var searchData=
[
  ['arrest',['Arrest',['../classcrimen.html#acf24dca899efd9bf99574f3be0b5ce52',1,'crimen']]]
];
