var searchData=
[
  ['latitude',['Latitude',['../classcrimen.html#adaf728df1dacff5a93678d3feb512b7f',1,'crimen']]],
  ['locationdescription',['LocationDescription',['../classcrimen.html#a221f7065c470883388174f19ea34d1f3',1,'crimen']]],
  ['longitude',['Longitude',['../classcrimen.html#a9ffd3c64d12cc4b963b890b8db645964',1,'crimen']]]
];
