var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classfecha.html#a9787de38b43ae62ba2c0812f3dd18394',1,'fecha::operator&lt;&lt;()'],['../classcrimen.html#a70d7dbf132d06cb3c889042765a7da2e',1,'crimen::operator&lt;&lt;()'],['../classconjunto.html#ae54b721035471d372f29c0335c42734a',1,'conjunto::operator&lt;&lt;()']]]
];
