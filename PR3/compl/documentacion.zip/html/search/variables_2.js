var searchData=
[
  ['date',['Date',['../classcrimen.html#a43fdb792dbc2e2927592fad7fb8b224c',1,'crimen']]],
  ['descr',['descr',['../classconjunto_1_1description__iterator.html#a3af23f14ec44378308e577ba8c9c71e0',1,'conjunto::description_iterator::descr()'],['../classconjunto_1_1const__description__iterator.html#a46a1e768efcf3886d1ab9063b76dcbe7',1,'conjunto::const_description_iterator::descr()']]],
  ['description',['Description',['../classcrimen.html#aa51b9ddc58248aadefdb8fad7d4cd69b',1,'crimen']]],
  ['domestic',['Domestic',['../classcrimen.html#a53f0bfea0c8ebb03dda9bf7332057477',1,'crimen']]]
];
