var searchData=
[
  ['c_5fitv',['c_itv',['../classconjunto_1_1const__iterator.html#a6ffe0c493b12aa9f40dc1501f0c904fc',1,'conjunto::const_iterator::c_itv()'],['../classconjunto_1_1const__description__iterator.html#a41cc62c64850c507f4d6bbed318d8949',1,'conjunto::const_description_iterator::c_itv()'],['../classconjunto_1_1const__arrest__iterator.html#a3240c715891b3cd5ecf77e8747043fc9',1,'conjunto::const_arrest_iterator::c_itv()']]],
  ['casenumber',['CaseNumber',['../classcrimen.html#a710fbf07b3e543c2a1b2e625b144050a',1,'crimen']]]
];
