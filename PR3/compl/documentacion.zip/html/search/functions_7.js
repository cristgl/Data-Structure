var searchData=
[
  ['insert',['insert',['../classconjunto.html#aa65b9f7c4cb9bad6d4e40c1973095930',1,'conjunto']]],
  ['iterator',['iterator',['../classconjunto_1_1iterator.html#ae3ade272e78f6888c39ad44a8b4b152a',1,'conjunto::iterator::iterator()'],['../classconjunto_1_1iterator.html#a3bf3696bc5d44e24cb78e9a7401c047c',1,'conjunto::iterator::iterator(const iterator &amp;it)']]]
];
