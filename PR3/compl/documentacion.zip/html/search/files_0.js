var searchData=
[
  ['conjunto_2eh',['conjunto.h',['../conjunto_8h.html',1,'']]],
  ['crimen_2eh',['crimen.h',['../crimen_8h.html',1,'']]]
];
